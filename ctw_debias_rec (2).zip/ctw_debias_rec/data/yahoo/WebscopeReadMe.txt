==================================================================

Yahoo! Webscope ReadMe

The data included herein is provided as part of the Yahoo! Webscope program for use solely under the terms of a signed Yahoo! Data Sharing Agreement.

Any publication using this data should attribute Yahoo!, ideally in the bibliography of the paper, unless Yahoo! explicitly requests no attribution. Please include the phrase Yahoo! Webscope, the web address http://research.yahoo.com/Academic_Relations and the name of the specific dataset used, including version number if applicable. For example:

Yahoo! Webscope dataset ydata-ymusic-user-artist-ratings-v1_0
[http://research.yahoo.com/Academic_Relations]

Please send a copy of each paper and its full citation information to research-data-requests@yahoo-inc.com upon publication.

This data may be used only for academic research purposes and may not be used for any commercial purposes, by any commercial entity, or by any party not under a signed Data Sharing Agreement. The data may not be reproduced in whole or in part, may not be posted on the web, on internal networks, or in networked data stores, and may not be archived offsite. The data must be returned to Yahoo! at the end of the research project or in three years, whichever comes first.

This dataset was produced from Yahoo!'s records and has been reviewed by an internal board to assure that no personally identifiable information is revealed.  You may not perform any analysis, reverse engineering or processing of the data or any correlation with other data sources that could be used to determine or infer personally identifiable information.

Please refer to the Data Sharing Agreement for complete terms. Contact research-data-requests@yahoo-inc.com with questions.

==================================================================
