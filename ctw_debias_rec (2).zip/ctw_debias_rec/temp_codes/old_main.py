# -*- coding: utf-8 -*-
import numpy as np
import torch
from sklearn.metrics import roc_auc_score
from dataset import load_data
from models import MF_CVIB, MF
from utils import gini_index, get_user_wise_ctr, \
    rating_mat_to_sample, binarize, shuffle, minU, \
    ndcg_func, acc_func, mse_func

dataset_name = "coat"
np.random.seed(2020)
torch.manual_seed(2020)

x_train, y_train, x_test, y_test, num_user, num_item \
    =load_data(dataset_name)

print("# user: {}, # item: {}".format(num_user, num_item))

mf_cvib = MF_CVIB(num_user, num_item)
mf_cvib.fit(x_train, y_train,
    lr=0.01,
    batch_size=128,
    lamb=1e-4,
    alpha=10.0,
    # alpha=0.0,
    gamma=1e-5,
    # gamma=0.0,
    tol=1e-5,
    verbose=False)


test_pred = mf_cvib.predict(x_test)
mse_mf = mse_func(y_test, test_pred)
auc_mf = roc_auc_score(y_test, test_pred)
ndcg_res = ndcg_func(mf_cvib, x_test, y_test)

print("***"*5 + "[MF-CVIB]" + "***"*5)
print("[MF-CVIB] test mse:", mse_mf)
print("[MF-CVIB] test auc:", auc_mf)
print("[MF] ndcg@5:{:.6f}, ndcg@10:{:.6f}".format(
        np.mean(ndcg_res["ndcg_5"]), np.mean(ndcg_res["ndcg_10"])))
user_wise_ctr = get_user_wise_ctr(x_test,y_test,test_pred)
gi,gu = gini_index(user_wise_ctr)
print("***"*5 + "[MF-CVIB]" + "***"*5)
