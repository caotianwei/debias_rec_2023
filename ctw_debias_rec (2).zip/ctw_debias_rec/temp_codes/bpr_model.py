import torch
from torch import nn
from torch.nn import functional as F
from torch import optim
import random
import numpy as np
import pandas as pd
from bpr_data import DataLoaderBPRMF
from dataset import load_data


def save_model(model, current_epoch, last_best_epoch=None):
    pass

def evaluate(model, train_user_dict, test_user_dict, user_ids_batches, item_ids, K):
    pass

def early_stopping(recall_list, stopping_steps):
    best_recall = max(recall_list)
    best_step = recall_list.index(best_recall)
    if len(recall_list) - best_step - 1 >= stopping_steps:
        should_stop = True
    else:
        should_stop = False
    return best_recall, should_stop

def _L2_loss_mean(x):
    return torch.mean(torch.sum(torch.pow(x, 2), dim=1, keepdim=False) / 2.)

class BPRMF(nn.Module):

    def __init__(self, args,
                 n_users, n_items,
                 user_pre_embed=None, item_pre_embed=None):

        super(BPRMF, self).__init__()
        self.use_pretrain = args.use_pretrain

        self.n_users = n_users
        self.n_items = n_items
        self.embed_dim = args.embed_dim
        self.l2loss_lambda = args.l2loss_lambda

        self.user_embed = nn.Embedding(self.n_users, self.embed_dim)
        self.item_embed = nn.Embedding(self.n_items, self.embed_dim)

        if (self.use_pretrain == 1) and (user_pre_embed is not None):
            self.user_embed.weight = nn.Parameter(user_pre_embed)
        else:
            nn.init.xavier_uniform_(self.user_embed.weight, gain=nn.init.calculate_gain('relu'))

        if (self.use_pretrain == 1) and (item_pre_embed is not None):
            self.item_embed.weight = nn.Parameter(item_pre_embed)
        else:
            nn.init.xavier_uniform_(self.item_embed.weight, gain=nn.init.calculate_gain('relu'))


    def predict(self, user_ids, item_ids):
        """
        user_ids:   number of users to evaluate   (n_eval_users)
        item_ids:   number of items to evaluate   (n_eval_items)
        """
        user_embed = self.user_embed(user_ids)                              # (n_eval_users, embed_dim)
        item_embed = self.item_embed(item_ids)                              # (n_eval_items, embed_dim)
        cf_score = torch.matmul(user_embed, item_embed.transpose(0, 1))     # (n_eval_users, n_eval_items)
        return cf_score


    def calc_loss(self, user_ids, item_pos_ids, item_neg_ids):
        """
        user_ids:       (batch_size)
        item_pos_ids:   (batch_size)
        item_neg_ids:   (batch_size)
        """
        user_embed = self.user_embed(user_ids)              # (batch_size, embed_dim)
        item_pos_embed = self.item_embed(item_pos_ids)      # (batch_size, embed_dim)
        item_neg_embed = self.item_embed(item_neg_ids)      # (batch_size, embed_dim)

        pos_score = torch.sum(user_embed * item_pos_embed, dim=1)       # (batch_size)
        neg_score = torch.sum(user_embed * item_neg_embed, dim=1)       # (batch_size)

        cf_loss = (-1.0) * F.logsigmoid(pos_score - neg_score)
        cf_loss = torch.mean(cf_loss)

        l2_loss = _L2_loss_mean(user_embed) + _L2_loss_mean(item_pos_embed) + _L2_loss_mean(item_neg_embed)
        loss = cf_loss + self.l2loss_lambda * l2_loss
        return loss


    def forward(self, mode, *input):
        if mode == 'train':
            return self.calc_loss(*input)


    def fit(args):
        # seed
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)

        # log_save_id = create_log_id(args.save_dir)
        # logging_config(folder=args.save_dir, name='log{:d}'.format(log_save_id), no_console=False)
        print(args)

        # GPU / CPU
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # load data
        data = DataLoaderBPRMF(args)

        user_ids = list(data.test_user_dict.keys())
        user_ids_batches = [user_ids[i: i + args.test_batch_size] for i in range(0, len(user_ids), args.test_batch_size)]
        user_ids_batches = [torch.LongTensor(d).to(device) for d in user_ids_batches]
        item_ids = torch.arange(data.n_items, dtype=torch.long).to(device)

        # construct model & optimizer
        model = BPRMF(args, data.n_users, data.n_items)
        model.to(device)
        print(model)

        optimizer = optim.Adam(model.parameters(), lr=args.lr)

        # initialize metrics
        best_epoch = -1
        epoch_list = []
        precision_list = []
        recall_list = []
        ndcg_list = []

        # train model
        for epoch in range(1, args.n_epoch + 1):
            model.train()

            # train cf
            total_loss = 0
            n_batch = data.n_cf_train // data.train_batch_size + 1

            for iter in range(1, n_batch + 1):
                batch_user, batch_pos_item, batch_neg_item = data.generate_train_batch(data.train_user_dict)
                batch_user = batch_user.to(device)
                batch_pos_item = batch_pos_item.to(device)
                batch_neg_item = batch_neg_item.to(device)
                batch_loss = model('train', batch_user, batch_pos_item, batch_neg_item).mean()

                batch_loss.backward()
                optimizer.step()
                optimizer.zero_grad()
                total_loss += batch_loss.item()

                if (iter % args.print_every) == 0:
                    print('CF Training: Epoch {:04d} Iter {:04d} | Iter Mean Loss {:.4f}'.format(epoch, iter, total_loss / iter))
            print('CF Training: Epoch {:04d} Total Iter {:04d} | Iter Mean Loss {:.4f}'.format(epoch, n_batch, total_loss / n_batch))

            # evaluate cf
            if (epoch % args.evaluate_every) == 0:
                _, precision, recall, ndcg = evaluate(model, data.train_user_dict, data.test_user_dict, user_ids_batches, item_ids, args.K)
                print('CF Evaluation: Epoch {:04d} | Precision {:.4f} Recall {:.4f} NDCG {:.4f}'.format(epoch, precision, recall, ndcg))

                epoch_list.append(epoch)
                precision_list.append(precision)
                recall_list.append(recall)
                ndcg_list.append(ndcg)
                best_recall, should_stop = early_stopping(recall_list, args.stopping_steps)

                if should_stop:
                    break

                if recall_list.index(best_recall) == len(recall_list) - 1:
                    save_model(model, epoch, best_epoch)
                    print('Save model on epoch {:04d}!'.format(epoch))
                    best_epoch = epoch

        # save model
        save_model(model, epoch)

        # save metrics
        _, precision, recall, ndcg = evaluate(model, data.train_user_dict, data.test_user_dict, user_ids_batches, item_ids, args.K)
        print('Final CF Evaluation: Precision {:.4f} Recall {:.4f} NDCG {:.4f}'.format(precision, recall, ndcg))

        epoch_list.append(epoch)
        precision_list.append(precision)
        recall_list.append(recall)
        ndcg_list.append(ndcg)

        metrics = pd.DataFrame([epoch_list, precision_list, recall_list, ndcg_list]).transpose()
        metrics.columns = ['epoch_idx', 'precision@{}'.format(args.K), 'recall@{}'.format(args.K), 'ndcg@{}'.format(args.K)]
        metrics.to_csv(args.save_dir + '/metrics.tsv', sep='\t', index=False)


x_train, y_train, x_test, y_test, num_user, num_item = load_data('yahoo')
print(x_train.shape)